import { useEffect, useState } from "react";
import { Navbar } from "../../components/Navbar";

import styles from "./index.module.css"

export default function HomePage() {

  const [inputTexto, setInputTexto] = useState("");
  const [inputTeste, setInputTeste] = useState(0);

  const nome = "Victor";

  useEffect(() => {
    setInputTeste(inputTeste + 1);
  }, [inputTexto]);
  

  return (
    <div>
      <h1>Essa é a página inicial!!!!!!!!!!! {nome}</h1>
      <input placeholder="Mararra pau mole" type="text" name="" id="" onChange={(event) => {setInputTexto(event.target.value)}}/>
      <p>Texto: {inputTexto}</p>
      <p className={styles.container}>Vezes em que o estado foi mudado: {inputTeste}</p>
      <hr />
      <Navbar texto="Help"/>

      <Navbar texto={inputTexto}><p>Olá</p></Navbar>
    </div>
  );
}