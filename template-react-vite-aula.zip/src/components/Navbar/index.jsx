import { Link } from "react-router-dom";

import styles from "./index.module.css";

export function Navbar({texto, children}){



    return (
        <nav>
            <ul>
                <li className={styles.container}><Link to="/">Home Page</Link></li>
                <li><Link to="/about">About Page</Link></li>
                <li>{texto}</li>
            </ul>
            {children}
        </nav>
    );
}